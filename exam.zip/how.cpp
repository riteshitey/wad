#include <iostream>
using namespace std;
#include <bits/stdc++.h>



int main()
{
    cout<<"hello"<<endl;
    return 0;
}